
import React from 'react'
import ReactDOM from 'react-dom/client'
import TokenPage from './TokenPage'
import './style.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TokenPage />
  </React.StrictMode>,
)
