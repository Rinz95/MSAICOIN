
export default function TokenPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-yellow-100 p-8">
      <div className="max-w-4xl mx-auto rounded-2xl bg-white shadow-xl p-6 space-y-8">

        {/* Hero Section */}
        <div className="text-center space-y-2">
          <img src="/logo-msai-mole.png" alt="MSAI Mole Logo" className="w-20 h-20 mx-auto" />
          <h1 className="text-4xl font-bold text-yellow-600">MSAI COIN</h1>
          <p className="text-gray-600">Meme Smarter. Earn Faster. Powered by AI & Laughter.</p>
        </div>

        {/* Tokenomics Section */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-yellow-700">Tokenomics</h2>
          <ul className="grid grid-cols-2 gap-4 text-gray-700">
            <li>🪙 Total Supply: 1,000,000,000 $MSAI</li>
            <li>🎯 Viral Mining Rewards: 40%</li>
            <li>🎁 Community Airdrop: 20%</li>
            <li>👨‍💻 Developer & Team: 10%</li>
            <li>🏛️ DAO Reserve: 10%</li>
            <li>🌀 Ecosystem & Staking: 15%</li>
            <li>💧 Liquidity & Listing: 5%</li>
          </ul>
        </div>

        {/* Features Section */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-yellow-700">Key Features</h2>
          <ul className="list-disc list-inside text-gray-700">
            <li>🤖 AI-powered Meme Generator</li>
            <li>📈 Proof-of-Viral Mining: Earn based on meme popularity</li>
            <li>🖼️ Mint viral memes as tradable NFTs</li>
            <li>🗳️ Govern the ecosystem via Meme DAO</li>
          </ul>
        </div>

        {/* Call to Action */}
        <div className="text-center pt-6">
          <a href="https://t.me/msaimole" target="_blank" className="inline-block bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-6 rounded-xl shadow-md transition">Join the Molement</a>
        </div>
      </div>
    </div>
  );
}
